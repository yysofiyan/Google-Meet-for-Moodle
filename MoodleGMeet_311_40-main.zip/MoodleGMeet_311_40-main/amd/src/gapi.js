define(['mod_googlemeet/config', 'gapi'], function(unused, gapi) {
    return gapi;
});
